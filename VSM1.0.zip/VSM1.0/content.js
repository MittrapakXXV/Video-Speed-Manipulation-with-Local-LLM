// ===== Utility Functions =====
function createElement(tag, options = {}, parent = null) {
  const el = document.createElement(tag);
  Object.entries(options).forEach(([key, value]) => {
    if (key === "classList") el.classList.add(...value);
    else if (key in el) el[key] = value;
    else el.setAttribute(key, value);
  });
  if (parent) parent.appendChild(el);
  return el;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

// ===== Initialize Window =====
(function initUI() {
  // ลบเก่า
  const oldWindow = document.getElementById("UI_main_Window");
  if (oldWindow) oldWindow.remove();

  // สร้าง container หลัก
  const container = createElement("div", { id: "UI_main_Window" }, document.body);

  // Header
  const main_header = createElement("header", {
    id: "UI_main_Header",
    textContent: "Video Speed Manipulator"
  }, container);

  // Close Button
  const main_body = createElement("div", { id: "UI_main_Body" });
  let Toggle = false;
  const closeBtn = createElement("span", { id: "close-btn", textContent: "✖" }, main_header);

  function toggleBody() {
    Toggle = !Toggle;
    if (Toggle) container.appendChild(main_body);
    else if (container.contains(main_body)) container.removeChild(main_body);
  }

  closeBtn.addEventListener("click", toggleBody);
  closeBtn.addEventListener("touchstart", e => {
    toggleBody();
    e.preventDefault();
  }, { passive: false });

  // ====== Button Row 1 ======
  const buttonRow = createElement("div", { className: "button-row1" }, main_body);
  let CurrentSpeed = 1;

  function SetPlayRate(Speed, doc = document, set = false) {
    try {
      const videos = doc.getElementsByTagName("video");
      if (set) {
        CurrentSpeed = Speed;
      } else {
        CurrentSpeed = clamp(CurrentSpeed + Speed, 0, 15);
      }
      [...videos].forEach(v => v.playbackRate = CurrentSpeed);
      const input = doc.getElementById("custom-input");
      if (input) input.value = CurrentSpeed;
    } catch (err) {
      alert(err);
    }
  }

  // Reset Button
  createElement("img", {
    src: chrome.runtime.getURL("images/zero.png"),
    id: "reset_button",
    classList: ["row1_child"],
    onclick: () => {
      const video = document.querySelector("video");
      if (video) video.currentTime = 0;
    }
  }, buttonRow);

  // Speed Down
  createElement("img", {
    src: chrome.runtime.getURL("images/speeddown.png"),
    id: "VM_Speed_Down",
    classList: ["row1_child"],
    onclick: () => SetPlayRate(-1)
  }, buttonRow);

  // Custom Input
  createElement("input", {
    type: "text",
    id: "custom-input",
    placeholder: "1",
    value: "1",
    title: "Speed",
    classList: ["row1_child"],
    style: "text-align:center",
    onblur: e => SetPlayRate(Number(e.target.value), document, true)
  }, buttonRow);

  // Speed Up
  createElement("img", {
    src: chrome.runtime.getURL("images/speedup.png"),
    id: "VM_Speed_Up",
    classList: ["row1_child"],
    onclick: () => SetPlayRate(1)
  }, buttonRow);

  // End Button
  createElement("img", {
    src: chrome.runtime.getURL("images/end.png"),
    id: "VM_End",
    classList: ["row1_child"],
    onclick: () => {
      const video = document.querySelector("video");
      if (video) video.currentTime = video.duration;
    }
  }, buttonRow);

  // ====== Button Row 2 ======
  const buttonRow2 = createElement("div", { className: "button-row2" }, main_body);
  const AIText = createElement("textarea", {
    type: "text",
    id: "AI-Text-Output",
    value: "",
    placeholder: "Ollama's Response Output Message",
    classList: ["row2_child"],
    style: "text-align:left",
    title: "Output"
  }, buttonRow2);

  





   const buttonRow3 = createElement("div", { className: "button-row3" }, main_body);
  const input3 = createElement("input", {
    type: "text",
    id: "AI-Text-Input",
    placeholder: "Input Message Here...",
    classList: ["row3_child"],
    style: "text-align:left",
    title: "Input"
  }, buttonRow3);

  const SendImg = createElement("img", {
    src: chrome.runtime.getURL("images/end.png"),
    id: "AI_Send",
    classList: ["row3_child"]
  }, buttonRow3);

  SendImg.addEventListener("click", () => {
    console.log("Sent Prompt!");
    chrome.runtime.sendMessage(
      { action: "queryOllama", prompt: input3.value },
      response => {
        if (response.error) {
          console.error("Error from Ollama:", response.error);
        } else {
          console.log("Ollama says:", response.result);
          AIText.value = response.result;
        }
      }
    );
  });







  // ====== Dragging ======
  let isDragging = false, offsetX = 0, offsetY = 0;

  function startDrag(x, y) {
    isDragging = true;
    offsetX = x - container.offsetLeft;
    offsetY = y - container.offsetTop;
  }
  function moveDrag(x, y) {
    if (isDragging) {
      container.style.left = `${x - offsetX}px`;
      container.style.top = `${y - offsetY}px`;
      container.style.right = "auto";
    }
  }
  function endDrag() {
    isDragging = false;
  }

  main_header.addEventListener("mousedown", e => {
    startDrag(e.clientX, e.clientY);
    document.body.style.userSelect = "none";
  });
  document.addEventListener("mousemove", e => moveDrag(e.clientX, e.clientY));
  document.addEventListener("mouseup", () => {
    endDrag();
    document.body.style.userSelect = "";
  });

  main_header.addEventListener("touchstart", e => {
    const touch = e.touches[0];
    startDrag(touch.clientX, touch.clientY);
    e.preventDefault();
  }, { passive: false });
  document.addEventListener("touchmove", e => {
    const touch = e.touches[0];
    moveDrag(touch.clientX, touch.clientY);
    e.preventDefault();
  }, { passive: false });
  document.addEventListener("touchend", endDrag);

})();
