async function queryOllama(prompt) {
  const response = await fetch('http://localhost:11434/api/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'llama3.2',
      prompt: prompt,
      stream: false
    })
  });

  if (!response.ok) {
    throw new Error(`Ollama API error: ${response.status}`);
  } 

  const data = await response.json();
  return data.response;
}

// Example usage:
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'queryOllama') {
    queryOllama(request.prompt)
      .then(result => sendResponse({ result }))
      .catch(error => sendResponse({ error: error.message }));
    return true; // Keep the message channel open for async response
  }
});